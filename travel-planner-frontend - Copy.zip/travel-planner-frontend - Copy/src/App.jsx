import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Home from './components/Home';
import Trips from './components/Trips';
import Navbar from './components/Navbar';
import MyTrips from './components/MyTrips';

    
import SharedTrips from './components/SharedTrips';


function App() {

  // Simple auth check (you'll improve this later)
  const isLoggedIn = !!localStorage.getItem('token');
  return (
    <BrowserRouter>
      <Navbar />

     <div className="d-flex justify-content-center align-items-center" style={{ minHeight: 'calc(100vh - 56px)' }}>
        <Routes>
              <Route path="/" element={<Navigate to="/register" />} />

                    


          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
           <Route path="/home" element={isLoggedIn ? <Home /> : <Navigate to="/login" />} />
          <Route
            path="/create-trip"
            element={isLoggedIn ? <Trips /> : <Navigate to="/login" />}
          />
           <Route path="/my-trips" element={<MyTrips />} />
        <Route path="/shared-trips" element={<SharedTrips />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
