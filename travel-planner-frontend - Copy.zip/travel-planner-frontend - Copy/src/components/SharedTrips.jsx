import { useEffect, useState } from 'react';

function SharedTrips() {
  const [sharedTrips, setSharedTrips] = useState([]);
  const [tripsSharedByMe, setTripsSharedByMe] = useState([]);

  const fetchSharedTrips = () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    fetch('http://localhost:7890/api/shared-trips', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(setSharedTrips)
      .catch(() => console.error('Error fetching shared trips'));
  };

  const fetchTripsSharedByMe = () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    fetch('http://localhost:7890/api/shared-trips/shared-by-me', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(setTripsSharedByMe)
      .catch(() => console.error('Error fetching trips shared by me'));
  };

  useEffect(() => {
    fetchSharedTrips();
    fetchTripsSharedByMe();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Trips Shared With You</h2>
      {sharedTrips.length === 0 ? (
        <p>No trips shared with you yet.</p>
      ) : (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Title</th>
              <th>Destination</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Notes</th>
              <th>Owner</th>
            </tr>
          </thead>
          <tbody>
            {sharedTrips.map((trip) => (
              <tr key={trip.id}>
                <td>{trip.title}</td>
                <td>{trip.destination}</td>
                <td>{trip.startDate}</td>
                <td>{trip.endDate}</td>
                <td>{trip.notes}</td>
                <td>{trip.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <h2 className="mt-5">Trips I Shared With Others</h2>
      {tripsSharedByMe.length === 0 ? (
        <p>No trips shared by you yet.</p>
      ) : (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Title</th>
              <th>Destination</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Notes</th>
              <th>Shared With</th>
            </tr>
          </thead>
          <tbody>
            {tripsSharedByMe.map((trip) => (
              <tr key={trip.id}>
                <td>{trip.title}</td>
                <td>{trip.destination}</td>
                <td>{trip.startDate}</td>
                <td>{trip.endDate}</td>
                <td>{trip.notes}</td>
                <td>{trip.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default SharedTrips;
