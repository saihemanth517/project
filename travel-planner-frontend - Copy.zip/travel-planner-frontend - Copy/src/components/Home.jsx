// src/components/Home.jsx
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

function Home() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');

  useEffect(() => {
    // Simulate getting the username from localStorage or backend
    const user = localStorage.getItem('username') || 'Traveler';
    setUsername(user);
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Welcome, {username} 👋</h2>

      <div className="row text-center">
        <div className="col-md-4">
          <div className="card bg-light mb-3 shadow-sm">
            <div className="card-body">
              <h5 className="card-title">Create a New Trip</h5>
              <p className="card-text">Start planning your next adventure.</p>
              <button className="btn btn-primary" onClick={() => navigate('/create-trip')}>
                Create Trip
              </button>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card bg-light mb-3 shadow-sm">
            <div className="card-body">
              <h5 className="card-title">My Trips</h5>
              <p className="card-text">View and manage your trips.</p>
              <button className="btn btn-success" onClick={() => navigate('/my-trips')}>
                View My Trips
              </button>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card bg-light mb-3 shadow-sm">
            <div className="card-body">
              <h5 className="card-title">Shared Trips</h5>
              <p className="card-text">Trips shared with or by you.</p>
              <button className="btn btn-info" onClick={() => navigate('/shared-trips')}>
                View Shared Trips
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
