import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';


function MyTrips() {
  const [trips, setTrips] = useState([]);
  const [message, setMessage] = useState('');
  const [editingTrip, setEditingTrip] = useState(null);
  const [sharingTripId, setSharingTripId] = useState(null);
  const [shareEmail, setShareEmail] = useState('');
  const navigate = useNavigate();

  const fetchTrips = () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setMessage('Not logged in. Please login to view trips.');
      return;
    }
    fetch('http://localhost:7890/api/trips', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Failed to fetch trips');
      })
      .then(data => {
        setTrips(data);
        setMessage('');
      })
      .catch(() => setMessage('Failed to fetch trips.'));
  };

  useEffect(() => {
    fetchTrips();
  }, []);

  const onTripCreated = () => {
    fetchTrips(); // refresh list after creation
    navigate('/my-trips');
  };

  const handleEditClick = (trip) => {
    setEditingTrip({ ...trip });
  };

  const handleDeleteTrip = async (tripId) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this trip?');
    if (!confirmDelete) return;

    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`http://localhost:7890/api/trips/${tripId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setMessage('Trip deleted.');
        fetchTrips();
      } else {
        setMessage('Failed to delete trip.');
      }
    } catch {
      setMessage('Error deleting trip.');
    }
  };

  const handleShareTrip = async (tripId) => {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`http://localhost:7890/api/shared-trips/share`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ tripId, usernameToShareWith: shareEmail })
      });

      if (res.ok) {
        setMessage('Trip shared successfully!');
        setShareEmail('');
        setSharingTripId(null);
      } else {
        const err = await res.json();
        setMessage(`Failed to share: ${err.message || 'Unknown error'}`);
      }
    } catch {
      setMessage('Error sharing trip.');
    }
  };

  return (
    <div className="container mt-5">
      <h2>My Trips</h2>

   

      {message && <div className="alert alert-info mt-3">{message}</div>}

      {trips.length === 0 ? (
        <p className="mt-3">No trips found.</p>
      ) : (
        <table className="table table-striped mt-4">
          <thead>
            <tr>
              <th>Title</th>
              <th>Destination</th>
              <th>Start</th>
              <th>End</th>
              <th>Notes</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trips.map((trip) => (
              <tr key={trip.id}>
                <td>{trip.title}</td>
                <td>{trip.destination}</td>
                <td>{trip.startDate}</td>
                <td>{trip.endDate}</td>
                <td>{trip.notes}</td>
                <td>
                  <button
                    className="btn btn-sm btn-warning me-2"
                    onClick={() => handleEditClick(trip)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger me-2"
                    onClick={() => handleDeleteTrip(trip.id)}
                  >
                    Delete
                  </button>
                  <button
                    className="btn btn-sm btn-info"
                    onClick={() => setSharingTripId(trip.id)}
                  >
                    Share
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {sharingTripId && (
        <div className="mt-4">
          <h5>Share Trip</h5>
          <div className="input-group">
            <input
              type="text"
              placeholder="Enter username to share with"
              className="form-control"
              value={shareEmail}
              onChange={(e) => setShareEmail(e.target.value)}
            />
            <button
              className="btn btn-primary"
              onClick={() => handleShareTrip(sharingTripId)}
            >
              Share
            </button>
            <button
              className="btn btn-secondary"
              onClick={() => setSharingTripId(null)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default MyTrips;
