import { Link, useLocation, useNavigate } from 'react-router-dom';

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const token = localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  const isRegisterPage = location.pathname === '/register';
  const isLoginPage = location.pathname === '/login';
  const isTripsPage = location.pathname === '/trips';

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand" to="/home">Travel Planner</Link>

        <div className="collapse navbar-collapse">
          <ul className="navbar-nav ms-auto">
            {isRegisterPage && (
              <li className="nav-item">
                <Link className="nav-link" to="/login">Login</Link>
              </li>
            )}

            {isLoginPage && token && (
              <li className="nav-item">
                <button className="btn btn-outline-light ms-2" onClick={handleLogout}>
                  Logout
                </button>
              </li>
            )}

            {isTripsPage && token && (
              <>
                <li className="nav-item">
  <Link className="nav-link" to="/create-trip">Create Trip</Link>
</li>
               <li className="nav-item">
              <Link className="nav-link" to="/my-trips">My Trips</Link>
            </li>
             <li className="nav-item">
      <Link className="nav-link" to="/shared-trips">Shared Trips</Link>
    </li>
             
                <li className="nav-item">
                  <button className="btn btn-outline-light ms-2" onClick={handleLogout}>
                    Logout
                  </button>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
