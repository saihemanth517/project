import { useState } from 'react';

function CreateTrip({ onTripCreated }) {
  const [form, setForm] = useState({
    title: '',
    destination: '',
    startDate: '',
    endDate: '',
    notes: ''
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('Creating trip...');

    const token = localStorage.getItem('token');

    if (!token) {
      setMessage('You must be logged in.');
      return;
    }

    try {
      const res = await fetch('http://localhost:7890/api/trips', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(form)
      });

      if (res.ok) {
        setMessage('Trip created successfully!');
        setForm({ title: '', destination: '', startDate: '', endDate: '', notes: '' });

        // Notify parent component (Trips) to refresh the list
        if (onTripCreated) onTripCreated();
      } else {
        const data = await res.json();
        setMessage('Failed to create trip: ' + (data.message || res.statusText));
      }
    } catch (err) {
      setMessage('Error connecting to backend.');
    }
  };

  return (
    <div className="card p-4 mb-4" style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h3>Create New Trip</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input
            type="text"
            name="title"
            className="form-control"
            value={form.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Destination</label>
          <input
            type="text"
            name="destination"
            className="form-control"
            value={form.destination}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Start Date</label>
          <input
            type="date"
            name="startDate"
            className="form-control"
            value={form.startDate}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">End Date</label>
          <input
            type="date"
            name="endDate"
            className="form-control"
            value={form.endDate}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Notes</label>
          <textarea
            name="notes"
            className="form-control"
            value={form.notes}
            onChange={handleChange}
            rows={3}
          />
        </div>

        <button type="submit" className="btn btn-success w-100">Create Trip</button>
      </form>

      {message && <div className="alert alert-info mt-3">{message}</div>}
    </div>
  );
}

export default CreateTrip;
